class DIRECTION:
    UP = 'up'
    DOWN = 'down'