__version__ = '0.1.0'
from .config import DIRECTION
# from .main import _test
from .main import getTPs
from .main import plot